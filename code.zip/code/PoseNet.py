# coding=utf-8
"""This code is to build a regression model for hand pose estimation
author: lijia
using tensorflow backend
update time 2017/6/15
"""
from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from util.load_data import load_data
from util.transform import rotateHand
import numpy as np
import math
import cv2
import h5py
import random
import time
import matplotlib.pyplot as ply
from keras.models import Model
from keras.layers.advanced_activations import LeakyReLU
from keras.layers import Dense, Conv2D, Dropout, Input, MaxPool2D, Flatten, UpSampling2D, Conv2DTranspose, ZeroPadding2D
from keras.layers.merge import concatenate
from keras.layers import add, Lambda, Activation, BatchNormalization  # Applies an activation function to an output
from keras import backend as K
from keras.optimizers import SGD, Adam, RMSprop
import tensorflow as tf
from keras.callbacks import TensorBoard, EarlyStopping, ReduceLROnPlateau, \
    ModelCheckpoint, LearningRateScheduler
from keras.regularizers import l2
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


# Define a slice layer using Lamda layer


def slice(x, h1, h2, w1, w2):
    """ Define a tensor slice function
    """
    return x[:, h1:h2, w1:w2, :]


# Notice!!!!  index of x.shape[0]  ':'    is needed when slicing!!

# Define a region regress block
def region_regress(input_tensor, fc1_dim, droprate1, fc2_dim, droprate2):
    x = Flatten()(input_tensor)  # this converts our 3D feature maps to 1D feature vectors
    # 在连接 3D tensor 和 全连接层之间，需要先对3D tensor进行扁平化处理 Flatten() !!!
    x = Dense(fc1_dim, kernel_initializer='he_normal')(x)
    x = BatchNormalization(epsilon=1e-05, momentum=0.9)(x)
    x = LeakyReLU(alpha=0.01)(x)
    # x = Activation('relu')(x)
    x = Dropout(droprate1)(x)

    x = Dense(fc2_dim, kernel_initializer='he_normal')(x)
    x = BatchNormalization(epsilon=1e-05, momentum=0.9)(x)
    x = LeakyReLU(alpha=0.01)(x)
    # x = Activation('relu')(x)
    x = Dropout(droprate2)(x)
    return x


# Define conve_bn_relu block
def conve_bn_relu(input_tensor, filter_number, kernel=(3, 3), padding='same'):
    x = Conv2D(filter_number, kernel, padding=padding, activation=None, kernel_initializer='he_normal')(input_tensor)
    x = BatchNormalization(epsilon=1e-05, axis=3, momentum=0.9)(x)
    # x = Activation(activation='relu')(x)
    x = LeakyReLU(alpha=0.01)(x)
    return x


# Define Hourglass residual block
# Don't change feature maps' size, only change the depth of feature maps.
def residual_block(channel_m_tensor, output_channel_n=128):
    """
    Output a tensor of n channels given a tensor of m channels
    :param channel_m_tensor: input tensor
    :param output_channel_n: the channel of output tensor
    :return: 
    """
    intermediate = BatchNormalization(epsilon=1e-05, axis=3, momentum=0.9)(channel_m_tensor)
    # intermediate = Activation('relu')(intermediate)
    intermediate = LeakyReLU(alpha=0.01)(intermediate)
    intermediate = Conv2D(output_channel_n // 2, (1, 1), padding='same',
                          kernel_initializer='he_normal')(intermediate)  # kernal=1 to shield computation

    intermediate = BatchNormalization(epsilon=1e-05, axis=3, momentum=0.9)(intermediate)
    # intermediate = Activation('relu')(intermediate)
    intermediate = LeakyReLU(alpha=0.01)(intermediate)
    intermediate = Conv2D(output_channel_n // 2, (3, 3), padding='same', kernel_initializer='he_normal')(intermediate)
    intermediate = BatchNormalization(epsilon=1e-05, axis=3, momentum=0.9)(intermediate)
    # intermediate = Activation('relu')(intermediate)
    intermediate = LeakyReLU(alpha=0.01)(intermediate)
    intermediate = Conv2D(output_channel_n, (1, 1), padding='same', kernel_initializer='he_normal')(intermediate)
    x = Conv2D(output_channel_n, (1, 1), padding='same', kernel_initializer='he_normal')(channel_m_tensor)
    output_tensor = add([intermediate, x])
    return output_tensor


def first_oder_hourglass(input_tensor, n_channel, intermediate_channel=128):
    """
    Extract features of n channels while remain the size of feature maps.
    :param input_tensor: 
    :param intermediate_channel: the channels of intermediate feature maps
    :param n_channel: output channel
    :return: the same size feature maps
    """
    x = residual_block(input_tensor, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=n_channel)
    intermediate = MaxPool2D((2, 2))(input_tensor)
    # intermediate = Conv2D(K.int_shape(input_tensor)[-1], (4, 4), padding='same',
    #                       strides=2, activation='relu', kernel_initializer='he_normal')(input_tensor)

    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)  # 下面第二条支路的中间 channel数
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=n_channel)
    intermediate = residual_block(intermediate, output_channel_n=n_channel)
    intermediate = UpSampling2D((2, 2))(intermediate)  # call tf.image.resize_nearest_neighbor

    # intermediate = Conv2DTranspose(n_channel, (4, 4), padding='same',
    #                                strides=2, activation='relu', kernel_initializer='he_normal')(intermediate)
    # todo: the upsampling2D in keras is tiling or nearest interpolating, 使用upsampling2D, Deconve instead
    output_tensor = add([x, intermediate])
    return output_tensor


def second_oder_hourglass(input_tensor, n_channel, intermediate_channel=128):
    x = residual_block(input_tensor, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=n_channel)
    intermediate = MaxPool2D((2, 2))(input_tensor)
    # intermediate = Conv2D(K.int_shape(input_tensor)[-1], (4, 4), padding='same',
    #                       strides=2, activation='relu', kernel_initializer='he_normal')(input_tensor)

    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)

    # replace a residual block with first oder hourglass
    intermediate = first_oder_hourglass(intermediate, n_channel=n_channel, intermediate_channel=intermediate_channel)

    intermediate = residual_block(intermediate, output_channel_n=n_channel)

    intermediate = UpSampling2D((2, 2))(intermediate)  # call tf.image.resize_nearest_neighbor
    # intermediate = Conv2DTranspose(n_channel, (4, 4), padding='same',
    #                                strides=2, kernel_initializer='he_normal', activation='relu')(intermediate)
    # todo: the upsampling2D in keras is tiling or nearest interpolating, 使用upsampling2D, Deconve instead
    output_tensor = add([x, intermediate])
    return output_tensor


# todo: third oder hourglass
def third_oder_hourglass(input_tensor, n_channel, intermediate_channel=128):
    x = residual_block(input_tensor, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=intermediate_channel)
    x = residual_block(x, output_channel_n=n_channel)
    intermediate = MaxPool2D((2, 2))(input_tensor)
    # intermediate = Conv2D(K.int_shape(input_tensor)[-1], (4, 4), padding='same',
    #                       strides=2, activation='relu', kernel_initializer='he_normal')(input_tensor)

    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)
    intermediate = residual_block(intermediate, output_channel_n=intermediate_channel)

    # replace a residual block with second oder hourglass
    intermediate = second_oder_hourglass(intermediate, n_channel=n_channel, intermediate_channel=intermediate_channel)

    intermediate = residual_block(intermediate, output_channel_n=n_channel)
    intermediate = UpSampling2D((2, 2))(intermediate)  # call tf.image.resize_nearest_neighbor
    # todo: the upsampling2D in keras is tiling or nearest interpolating, 使用upsampling2D, Deconve instead
    # intermediate = Conv2DTranspose(n_channel, (4, 4), padding='same', kernel_initializer='he_normal',
    #                                strides=2, activation='relu')(intermediate)
    output_tensor = add([x, intermediate])
    return output_tensor


# # Define Smooth L1 Loss
# def l1_smooth_loss(y_true, y_pred):
#     abs_loss = tf.abs(y_true - y_pred)
#     sq_loss = 0.5 * (y_true - y_pred)**2
#     l1_loss = tf.where(tf.less(abs_loss, 1.0), sq_loss, abs_loss - 0.5)
#     return tf.reduce_sum(l1_loss)
#
# Define the smooth L1 loss
def l1_smooth_loss(y_true, y_pred):
    # joint_weight = np.ones(105)
    # double = [0, 1, 2, 6, 7, 8, 12, 13, 14, 18, 19, 20, 24, 25, 26, 27, 28, 29]
    # joint_weight[double] = 1.5   # 设置手指的端点的惩罚系数为2.0， 是不是有点过大了
    # 改变这里的同时需要改变 losses.py中的 joint_weight值
    x = K.abs(y_true - y_pred)
    x = tf.where(tf.less(x, 1.0), 0.5 * x ** 2, x - 0.5)
    # x = 105 * K.max(x, axis=-1)  # using the backend function
    # x = np.ones(105) * np.max(x)
    return K.sum(x, axis=-1)


# #######################################   Build Model   ################################
# build a cnn model
input_img = Input(shape=(128, 128, 1))

# branch of 1*3 and 1*5 filters and merge
conv1_1_3 = conve_bn_relu(input_img, 16, (3, 3))

# conv2_1_5 = conve_bn_relu(input_img, 8, (1, 5))
# conv2_5_1 = conve_bn_relu(conv2_1_5, 8, (5, 1))

# concatenate multi scale feature map
maxpool1 = MaxPool2D((2, 2))(conv1_1_3)

# residual block and hourglass block

residual_block_1 = residual_block(maxpool1, 32)
maxpool2 = MaxPool2D((2, 2))(residual_block_1)

residual_block_2 = residual_block(maxpool2, 64)
maxpool3 = MaxPool2D((2, 2))(residual_block_2)

# first_oder_hour_1 = first_oder_hourglass(maxpool2, 32, intermediate_channel=16)
# maxpool3 = MaxPool2D((2, 2))(maxpool2)

third_oder_hour1 = third_oder_hourglass(maxpool3, 256, intermediate_channel=128)
# residual_block_2 = residual_block(second_oder_hour1, 128)
maxpool4 = MaxPool2D((2, 2))(third_oder_hour1)

# Add slice layer
slice_1 = Lambda(slice, arguments={'h1': 0, 'h2': 4, 'w1': 0, 'w2': 4})(maxpool4)
# As for tensorfow backend, Lambda doesn't need output shape argument
slice_2 = Lambda(slice, arguments={'h1': 0, 'h2': 4, 'w1': 4, 'w2': 8})(maxpool4)
slice_3 = Lambda(slice, arguments={'h1': 4, 'h2': 8, 'w1': 0, 'w2': 4})(maxpool4)
slice_4 = Lambda(slice, arguments={'h1': 4, 'h2': 8, 'w1': 4, 'w2': 8})(maxpool4)

# local regress
regress_1 = region_regress(slice_1, 1024, 0.5, 1024, 0.5)
regress_2 = region_regress(slice_2, 1024, 0.5, 1024, 0.5)
regress_3 = region_regress(slice_3, 1024, 0.5, 1024, 0.5)
regress_4 = region_regress(slice_4, 1024, 0.5, 1024, 0.5)

# Regression Ensemble
concat = concatenate([regress_1, regress_2, regress_3, regress_4])  # axis=-1?

fc_concat = Dense(1024, kernel_initializer='he_normal')(concat)  # , activation='relu'
fc_concat = BatchNormalization(epsilon=1e-05, momentum=0.9)(fc_concat)
# fc_concat = Activation('relu')(fc_concat)
fc_concat = LeakyReLU(alpha=0.01)(fc_concat)
linear = Dropout(0.5)(fc_concat)
pose = Dense(105, activation=None)(linear)  # 因为使用的是归一化到[-1, 1]的相对坐标  activation='tanh'


# #####################################  Define Model #############################
def build_model():
    return Model(input_img, pose)


posenet = build_model()

# ###########  TODO: my debug and examine job #############

# # 保存模型到png图片格式， 打印模型计算的中间结果用于检查模型是否运算正确
#
# ############### #####################################
# ############ plot model
# from keras.utils import plot_model
# plot_model(posenet, to_file='model.png', show_shapes=True)

# ##################  Print intermediate layer to examine if the network is correct! 打印输出中间层计算结果
# j = 0
# for i in posenet.layers:
#     get_3rd_layer_output = K.function([posenet.layers[0].input, K.learning_phase()],
#                                       [posenet.layers[j].output])
#     layer_output = get_3rd_layer_output([input_img[:10], 0])[0]
# ## # output in test mode = 0, output in train mode = 1
#     j += 1
#     print('the layer {} shape is {}'.format(j, layer_output.shape))


# todo: fit model
# Set learning rate
lr = 0.0005
sgd = SGD(lr=lr, decay=5e-4, momentum=0.9, nesterov=True)
adm = Adam(lr=0.0005)  # 0.001  试试0.25？？？  0.0005最终
rmsprop = RMSprop(lr=5e-4)

posenet.compile(optimizer=adm, loss=l1_smooth_loss)  #
posenet.summary()

# load pre-trained weight
# posenet.load_weights('weight/[13.00mm]my_model_sun_my_aug_final_0.25.h5')

# # # save and load model  保存和载入模型
# posenet.save('my_model.h5')
# from keras.models import load_model  # 载入之前的权值  以及  ××××××优化器的状态×××××××××  继续训练
# posenet = load_model('check_point/weights.99-0.21.hdf5')
# posenet.summary()

log_filepath = './log/with_rotation'
tb_cb = TensorBoard(log_dir=log_filepath, write_graph=False)  # , histogram_freq=1, write_grads=True
el_stop = EarlyStopping('val_loss', patience=50, verbose=1, mode='auto')
rd_lr = ReduceLROnPlateau('val_loss', factor=0.2, patience=20, verbose=1, mode='auto')
check_point = ModelCheckpoint('./check_point/weights.{epoch:02d}-{val_loss:.2f}.hdf5', monitor='val_loss', verbose=1,
                              save_best_only=True, save_weights_only=False, period=10)  # 30


def step_decay(epoch):
    lrate = 0.005
    if epoch % 10 == 0:
        lrate /= 10
    return lrate


# posenet.load_weights('check_point/weights.89-0.25.hdf5')  # load weight and continue training,如果是只保存了权值，那么
# 权值的载入应该在模型定义之后，模型编译之前进行

lrate = LearningRateScheduler(step_decay)

# load data from h5 files
train_image, train_joint, train_com, test_image, test_joint, test_com = load_data()


# Define generator function
def data_generator():
    image = train_image
    joint = train_joint
    com = train_com
    batch_size = 256
    batch_images = np.ones((batch_size, 128, 128, 1))
    batch_labels = np.zeros((batch_size, 105))
    while True:
        for i in range(batch_size):
            # choose random index in data
            index = int(np.random.choice(len(image), 1))
            image_i = image[index].squeeze()  # convet to (128, 128)
            com_i = com[index]
            if np.random.randint(2):  # 随机选择是否进行变形，选择0.5概率进行变形
                # todo: 是不是每次都进行变形效果更好，保留0.5仍然会出现过拟合
                rox = np.random.uniform(0.8, 1.1)  # xy放大倍数
                roy = np.random.uniform(0.8, 1.1)  # xy放大倍数
                roz = np.random.uniform(0.95, 1.05)  # depth放大倍数
                image_ro = np.ones((128, 128), dtype=np.float32)
                cx = int(math.floor(128 * rox))
                cy = int(math.floor(128 * roy))
                image_i = cv2.resize(image_i, (cx, cy))
                if rox <= 1.0:
                    xstart = int(64 * (1 - rox))
                    xend = xstart + cx
                    if roy <= 1.0:
                        ystart = int(64 * (1 - roy))
                        yend = ystart + cy
                        image_ro[ystart:yend, xstart:xend] = image_i
                    else:
                        ystart = int(64 * (roy - 1))
                        yend = ystart + 128
                        image_ro[:, xstart:xend] = image_i[ystart:yend, :]
                else:
                    xstart = int(64 * (rox - 1))
                    xend = xstart + 128
                    if roy <= 1.0:
                        ystart = int(64 * (1 - roy))
                        yend = ystart + cy
                        image_ro[ystart:yend, :] = image_i[:, xstart:xend]
                    else:
                        ystart = int(64 * (roy - 1))
                        yend = ystart + 128
                        image_ro[:, :] = image_i[ystart:yend, xstart:xend]
                image_ro *= roz  # depth的值也做缩放, 但是不能加 np.clip，否则会破坏深度值。 改变depth也是间接地改变手的长宽比
                image_ro = image_ro.reshape(128, 128, 1)
                joint_o = joint[index].reshape(35, 3)
                joint_o[:, 0] = joint_o[:, 0] * rox  # joint的xzy坐标做不同变化
                joint_o[:, 1] = joint_o[:, 1] * roy  # joint的xzy坐标做不同变化
                joint_o[:, 2] = joint_o[:, 2] * roz
                joint_o = joint_o.reshape(105)
            else:
                image_ro = image_i.reshape(128, 128, 1)
                joint_o = joint[index]
            rotation = np.random.uniform(0, 360)
            batch_images[i], batch_labels[i] = rotateHand(image_ro, com_i, rotation, joint_o)
        yield batch_images, batch_labels


def data_generator1():
    image = train_image
    joint = train_joint
    com = train_com
    batch_size = 256
    batch_images = np.ones((batch_size, 128, 128, 1))
    batch_labels = np.zeros((batch_size, 105))
    while True:
        for i in range(batch_size):
            # choose random index in data
            index = int(np.random.choice(len(image), 1))
            image_i = image[index].squeeze()  # convet to (128, 128)
            com_i = com[index]
            joint_i = joint[index]
            if np.random.randint(2):  # 随机选择是否进行变形，选择0.5概率进行变形
                # todo: 是不是每次都进行变形效果更好，保留0.5仍然会出现过拟合
                rotation = np.random.uniform(0, 360)
                batch_images[i], batch_labels[i] = rotateHand(image_i, com_i, rotation, joint_i)

            else:
                # todo: 是不是每次都进行变形效果更好，保留0.5仍然会出现过拟合
                rox = np.random.uniform(0.8, 1.1)  # xy放大倍数
                roy = np.random.uniform(0.8, 1.1)  # xy放大倍数
                roz = np.random.uniform(0.95, 1.05)  # depth放大倍数
                image_ro = np.ones((128, 128), dtype=np.float32)
                cx = int(math.floor(128 * rox))
                cy = int(math.floor(128 * roy))
                image_i = cv2.resize(image_i, (cx, cy))
                if rox <= 1.0:
                    xstart = int(64 * (1 - rox))
                    xend = xstart + cx
                    if roy <= 1.0:
                        ystart = int(64 * (1 - roy))
                        yend = ystart + cy
                        image_ro[ystart:yend, xstart:xend] = image_i
                    else:
                        ystart = int(64 * (roy - 1))
                        yend = ystart + 128
                        image_ro[:, xstart:xend] = image_i[ystart:yend, :]
                else:
                    xstart = int(64 * (rox - 1))
                    xend = xstart + 128
                    if roy <= 1.0:
                        ystart = int(64 * (1 - roy))
                        yend = ystart + cy
                        image_ro[ystart:yend, :] = image_i[:, xstart:xend]
                    else:
                        ystart = int(64 * (roy - 1))
                        yend = ystart + 128
                        image_ro[:, :] = image_i[ystart:yend, xstart:xend]
                image_ro *= roz  # depth的值也做缩放, 但是不能加 np.clip，否则会破坏深度值。 改变depth也是间接地改变手的长宽比
                image_ro = image_ro.reshape(128, 128, 1)
                joint_o = joint[index].reshape(35, 3)
                joint_o[:, 0] = joint_o[:, 0] * rox  # joint的xzy坐标做不同变化
                joint_o[:, 1] = joint_o[:, 1] * roy  # joint的xzy坐标做不同变化
                joint_o[:, 2] = joint_o[:, 2] * roz
                joint_o = joint_o.reshape(105)

                batch_images[i], batch_labels[i] = image_ro, joint_o

        yield batch_images, batch_labels  #


# history = posenet.fit(train_image, train_joint, validation_data=(test_image, test_joint),
#             batch_size=256, epochs=450, shuffle=True, verbose=2,
#             callbacks=[rd_lr, check_point, tb_cb])  # , callbacks=[tb_cb]

# # # train with augmentation
posenet.fit_generator(data_generator1(), train_image.shape[0] // 256, epochs=500, verbose=2,
                      callbacks=[rd_lr, check_point], validation_data=(test_image, test_joint))
# # fit_generator没有 shuffle=True, 这就要求在生成器函数中需要有打乱操作

# # save the trained model's weight
# posenet.save_weights('trained_model_weight.h5')
#
# # # reload the model weights
# # posenet.load_weights('trained_model_weight.h5', by_name=True)  # load layers' weights by layer name
#
#
# save model and weights
posenet.save('my_model_rotate_l1_loss_v2.h5')

