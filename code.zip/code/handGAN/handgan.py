# coding:utf-8
# author: lijia
from __future__ import absolute_import
from __future__ import print_function
from __future__ import division

from keras import layers
from keras import optimizers
from keras.regularizers import l2
import keras.backend as K
from keras.models import Sequential, Model
import tensorflow as tf
import numpy as np
import h5py
import matplotlib.pyplot as plt
from utils.plot_images import save_imgs
from utils.image_history_buffer import ImageHistoryBuffer
import os
from keras.callbacks import TensorBoard
from utils.resnet50 import nn_base

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def write_log(callback, names, logs, batch_no):
    for name, value in zip(names, logs):
        summary = tf.Summary()
        summary_value = summary.value.add()
        summary_value.simple_value = value
        summary_value.tag = name
        callback.writer.add_summary(summary, batch_no)  # batch_no: global step
        callback.writer.flush()

# Define Smooth L1 Loss
def l1_smooth_loss(y_true, y_pred):
    abs_loss = tf.abs(y_true - y_pred)
    sq_loss = 0.5 * (y_true - y_pred) ** 2
    l1_loss = tf.where(tf.less(abs_loss, 1.0), sq_loss, abs_loss - 0.5)
    return tf.reduce_sum(l1_loss, axis=-1)


# set parameters
epochs = 30000
batch_size = 256
save_interval = 100

# load data
with h5py.File('data/train_0.h5') as f:
    X_noise = f['depth'][:]
    X_noise = np.transpose(X_noise, (0, 2, 3, 1))
    y_pose = f['joint'][:]

with h5py.File('data/test_2_0.h5') as f:
    X_noise2 = f['depth'][:]
    X_noise2 = np.transpose(X_noise2, (0, 2, 3, 1))
    y_pose2 = f['joint'][:]

X_noise = np.vstack((X_noise, X_noise2))
y_pose = np.vstack((y_pose, y_pose2))

# load data
with h5py.File('data/synth_train_0.h5') as f:
    X_refined = f['depth'][:]
    X_refined = np.transpose(X_refined, (0, 2, 3, 1))

with h5py.File('data/synth_test_2_0.h5') as f:
    X_refined2 = f['depth'][:]
    X_refined2 = np.transpose(X_refined2, (0, 2, 3, 1))

X_refined = np.vstack((X_refined, X_refined2))

print('channel mode: {}'.format(K.image_dim_ordering()))
print('the shape of noise depth images is {}'.format(X_noise.shape))
print('the shape of refined depth images is {}'.format(X_noise.shape))
print('the shape of joints is {}'.format(y_pose.shape))

# load data
with h5py.File('data/test_1_0.h5') as f:
    X_val = f['depth'][:]
    X_val = np.transpose(X_val, (0, 2, 3, 1))

with h5py.File('data/synth_test_1_0.h5') as f:
    Y_val = f['depth'][:]
    Y_val = np.transpose(Y_val, (0, 2, 3, 1))

print('the shape of validation depth images is {}'.format(X_val.shape))


# get the image shape
image_shape = X_noise.shape[1:]
image_height, image_width, image_channel = image_shape


# Define the generator
def build_generator(input_shape):  # LeakyRelu的alpha值取多少？
    input_tensor = layers.Input(shape=input_shape)

    input_tensor1 = layers.Lambda(lambda t: 0.5 * t + 0.5)(input_tensor)  # convert from [-1, 1] to [0, 1]
    # Encoder
    x = layers.Conv2D(16, (5, 5), strides=1, padding='same', activation='relu', name='conv_1')(input_tensor1)

    x = layers.Conv2D(32, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_1')(x)
    x = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_2')(x)

    x = layers.Conv2D(64, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_2')(x)
    x = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='conv_3')(x)

    # Dilated Conve layer: enlarge the receptive field
    x = layers.Conv2D(64, (3, 3), dilation_rate=2, padding='same', activation='relu', name='dilated_d2')(x)
    x = layers.Conv2D(64, (3, 3), dilation_rate=4, padding='same', activation='relu', name='dilated_d4')(x)
    x = layers.Conv2D(64, (3, 3), dilation_rate=8, padding='same', activation='relu', name='dilated_d8')(x)

    # Decoder
    x = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='con_v4')(x)

    x = layers.Conv2DTranspose(32, (4, 4), strides=2, padding='same',activation='relu',  name='deconv_s2_1')(x)
    x = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_5')(x)

    x = layers.Conv2DTranspose(16, (4, 4), strides=2, padding='same', activation='relu', name='deconv_s2_2')(x)
    x = layers.Conv2D(16, (3, 3), strides=1, padding='same', activation='relu', name='conv_6')(x)

    x = layers.Conv2D(image_channel, (3, 3), strides=1, padding='same', activation=None, name='last_layer')(x)
    # x = layers.Activation('tanh')(x)

    return Model(input_tensor, x)


def build_generator_skip(input_shape):
    """
    A generator with skip connections, which learns the residual of F(x) = Y - X
    :param input_shape: A tuple, specifying the shape of input tensor
    :return: return a keras model
    """
    input_tensor = layers.Input(shape=input_shape)
    input_tensor1 = layers.Lambda(lambda x: 0.5 * x + 0.5)(input_tensor)  # convert from [-1, 1] to [0, 1]

    # Encoder
    x1 = layers.Conv2D(16, (5, 5), strides=1, padding='same', activation='relu', name='conv_1')(input_tensor1)

    x2 = layers.Conv2D(32, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_1')(x1)

    x3 = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_2')(x2)

    x4 = layers.Conv2D(64, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_2')(x3)
    x5 = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='conv_3')(x4)

    # Dilated Conve layer: enlarge the receptive field
    x6 = layers.Conv2D(64, (3, 3), dilation_rate=2, padding='same', activation='relu', name='dilated_d2')(x5)
    x7 = layers.Conv2D(64, (3, 3), dilation_rate=4, padding='same', activation='relu', name='dilated_d4')(x6)

    x8 = layers.Conv2D(64, (3, 3), dilation_rate=8, padding='same', activation='relu', name='dilated_d8')(x7)
    x8 = layers.add([x5, x8])
    x8 = layers.Activation('relu')(x8)

    # Decoder
    x9 = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='con_v4')(x8)
    x9 = layers.add([x4, x9])
    x9 = layers.Activation('relu')(x9)

    x10 = layers.Conv2DTranspose(32, (4, 4), strides=2, padding='same', activation='relu', name='deconv_s2_1')(x9)
    x10 = layers.add([x3, x10])
    x10 = layers.Activation('relu')(x10)

    x11 = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_5')(x10)
    x11 = layers.add([x2, x11])
    x11 = layers.Activation('relu')(x11)

    x12 = layers.Conv2DTranspose(16, (4, 4), strides=2, padding='same', activation='relu', name='deconv_s2_2')(x11)
    # x12 = layers.add([x1, x12])
    # x12 = layers.Activation('relu')(x12)

    x13 = layers.Conv2D(16, (3, 3), strides=1, padding='same', activation='relu', name='conv_6')(x12)

    x14 = layers.Conv2D(image_channel, (3, 3), strides=1, padding='same', activation=None, name='last_layer')(x13)

    # output_tensor = layers.Lambda(lambda x: (x - 0.5) * 2)(x14)  # convert from [0, 1] to [-1, 1]

    return Model(input_tensor, x14)


def build_generator_original(input_shape):
    """
    A generator with skip connections, which learns the residual of F(x) = Y - X
    :param input_shape: A tuple, specifying the shape of input tensor
    :return: return a keras model
    """
    input_tensor = layers.Input(shape=input_shape)
    input_tensor1 = layers.Lambda(lambda x: 0.5 * x + 0.5)(input_tensor)  # convert from [-1, 1] to [0, 1]

    # Encoder
    x1 = layers.Conv2D(16, (5, 5), strides=1, padding='same', activation='relu', name='conv_1')(input_tensor1)

    x2 = layers.Conv2D(32, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_1')(x1)

    x3 = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_2')(x2)

    x4 = layers.Conv2D(64, (4, 4), strides=2, padding='same', activation='relu', name='conv_s2_2')(x3)
    x5 = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='conv_3')(x4)

    # Dilated Conve layer: enlarge the receptive field
    x6 = layers.Conv2D(64, (3, 3), dilation_rate=2, padding='same', activation='relu', name='dilated_d2')(x5)
    x7 = layers.Conv2D(64, (3, 3), dilation_rate=4, padding='same', activation='relu', name='dilated_d4')(x6)

    x8 = layers.Conv2D(64, (3, 3), dilation_rate=8, padding='same', activation='relu', name='dilated_d8')(x7)
    x8 = layers.add([x5, x8])
    x8 = layers.Activation('relu')(x8)

    # Decoder
    x9 = layers.Conv2D(64, (3, 3), strides=1, padding='same', activation='relu', name='con_v4')(x8)
    x9 = layers.add([x4, x9])
    x9 = layers.Activation('relu')(x9)

    x10 = layers.Conv2DTranspose(32, (4, 4), strides=2, padding='same', activation='relu', name='deconv_s2_1')(x9)
    x10 = layers.add([x3, x10])
    x10 = layers.Activation('relu')(x10)

    x11 = layers.Conv2D(32, (3, 3), strides=1, padding='same', activation='relu', name='conv_5')(x10)
    x11 = layers.add([x2, x11])
    x11 = layers.Activation('relu')(x11)

    x12 = layers.Conv2DTranspose(16, (4, 4), strides=2, padding='same', activation='relu', name='deconv_s2_2')(x11)
    x12 = layers.add([x1, x12])
    x12 = layers.Activation('relu')(x12)

    x13 = layers.Conv2D(16, (3, 3), strides=1, padding='same', activation='relu', name='conv_6')(x12)
    x14 = layers.Conv2D(image_channel, (3, 3), strides=1, padding='same', activation=None, name='last_layer')(x13)

    # output_tensor = layers.Lambda(lambda x: (x - 0.5) * 2)(x14)  # convert from [0, 1] to [-1, 1]
    return Model(input_tensor, x14)


def build_discriminator(input_shape):
    input_tensor = layers.Input(shape=input_shape)
    conv0_relu0 = layers.Conv2D(16, 3, padding='same', activation='relu', kernel_regularizer=l2(0.0005))(input_tensor)
    conv1 = layers.Conv2D(16, 3, padding='same', activation=None, kernel_regularizer=l2(0.0005))(conv0_relu0)
    pool_1 = layers.AveragePooling2D((2, 2))(conv1)
    pool_1 = layers.BatchNormalization(epsilon=1e-06, axis=3)(pool_1)
    relu2 = layers.Activation(activation='relu')(pool_1)
    conv2_0_relu2_0 = layers.Conv2D(32, (1, 1), padding='same', activation='relu', kernel_regularizer=l2(0.0005))(relu2)
    conv2_relu2 = layers.Conv2D(32, (3, 3), padding='same', activation='relu', kernel_regularizer=l2(0.0005))(conv2_0_relu2_0)
    conv3 = layers.Conv2D(32, (3, 3), padding='same', activation=None, kernel_regularizer=l2(0.0005))(conv2_relu2)

    # Add a residual block
    res1 = layers.add([conv2_0_relu2_0, conv3])

    pool2 = layers.AveragePooling2D((2, 2))(res1)
    pool2 = layers.BatchNormalization(epsilon=1e-06, axis=3)(pool2)
    relu3 = layers.Activation(activation='relu')(pool2)
    conv3_0_relu3_0 = layers.Conv2D(64, (1, 1), padding='same', activation='relu', kernel_regularizer=l2(0.0005))(relu3)
    conv4_relu4 = layers.Conv2D(64, (3, 3), padding='same', activation='relu', kernel_regularizer=l2(0.0005))(conv3_0_relu3_0)
    conv5 = layers.Conv2D(64, (3, 3), padding='same', activation=None, kernel_regularizer=l2(0.0005))(conv4_relu4)

    # Add the second residual block
    res2 = layers.add([conv3_0_relu3_0, conv5])

    pool3 = layers.AveragePooling2D((2, 2))(res2)
    pool3 = layers.BatchNormalization(epsilon=1e-06, axis=3)(pool3)
    relu5 = layers.Activation(activation='relu')(pool3)

    conv6 = layers.Conv2D(128, (3, 3), strides=2, padding='same', kernel_regularizer=l2(0.0005))(relu5)
    flattend = layers.Flatten()(conv6)
    dense1 = layers.Dense(2048, activation='relu')(flattend)
    dense2 = layers.Dense(512, activation='relu')(dense1)

    valid = layers.Dense(1, activation='sigmoid')(dense2)
    # pose = layers.Dense(42, activation='tanh')(dense2)

    return Model(input_tensor, valid)


def build_discriminator_easy(input_shape):
    input_tensor = layers.Input(shape=input_shape)
    x = layers.Conv2D(64, (4, 4), strides=2, padding='same', activation='relu')(input_tensor)
    x = layers.Dropout(0.5)(x)
    x = layers.Conv2D(48, (4, 4), strides=2, padding='same', activation='relu')(x)
    x = layers.Conv2D(32, (4, 4), strides=2, padding='same', activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.MaxPool2D((3, 3), strides=1, padding='same')(x)
    x = layers.Conv2D(16, (3, 3), strides=1, padding='same', activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Conv2D(16, (1, 1), strides=1, padding='same', activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Conv2D(image_channel, (1, 1), strides=1, padding='same', activation='relu')(x)
    valid = layers.Reshape((-1, 1))(x)

    return Model(input_tensor, valid)

def build_discriminator_resnet(input_shape):
    input_tensor = layers.Input(shape=input_shape)
    x = nn_base(input_tensor)
    x = layers.Conv2D(64, (1, 1), strides=1, padding='same', activation='relu')(x)
    x = layers.Conv2D(16, (1, 1), strides=1, padding='same', activation='relu')(x)
    x = layers.Conv2D(image_channel, (1, 1), strides=1, padding='same', activation='relu')(x)
    valid = layers.Reshape((-1, 1))(x)
    return Model(input_tensor, valid)


generator = build_generator_skip(image_shape)
generator.summary()

generator.load_weights('my_no_skip_model_relu_none_epoch_4900.hdf5')
print('******************  Loading weights of generator  ****************')

discriminator = build_discriminator_resnet(image_shape)
discriminator_output_shape = discriminator.output_shape
print('the output of discriminator', discriminator_output_shape, '*******************')
discriminator.summary()

discriminator.load_weights('my_discriminator_1800.hdf5')
print('******************  Loading weights of discriminator ****************')

d_optim = optimizers.Adam(lr=0.0008, clipvalue=1)
g_optim = optimizers.Adam(lr=0.0008, clipvalue=1)

# # # ----------------------#
# #       plot model        #
# # # ----------------------#
# from keras.utils import plot_model
#
# plot_model(discriminator, to_file='skip_generator.png', show_shapes=True)

generator.compile(loss='mse', optimizer=g_optim)

discriminator.compile(loss='binary_crossentropy', optimizer=d_optim)
discriminator.trainable = False

input = layers.Input(shape=image_shape)
gen_image = generator(input)
valid = discriminator(gen_image)
d_on_g = Model(input, [gen_image, valid])
d_on_g.summary()
d_on_g.compile(loss=['mse', 'binary_crossentropy'], loss_weights=[100, 1], optimizer=g_optim)
# 重建图像的损失和判别真假的损失的和（也就是total loss)，通过combined model传回给生成模型G


half_batch = int(batch_size / 2)

# --------------------------------------- #
# ------  log in Tensorboard  ---------------
# ------------------------------------   #

# log_path = './log/gan_try_1'
# callback = TensorBoard(log_path)
# callback.set_model(generator)
# train_names = ['train_loss', 'train_mae']
# val_names = ['val_loss', 'val_mae']


# # --------------------------------- # #
# #           Train the GAN           # #
# # --------------------------------- # #

image_history_buffer = ImageHistoryBuffer((0, image_height, image_width, image_channel),
                                          batch_size * 100, batch_size)

for epoch in range(epochs):

    # # ---------------------
    # #  Train Discriminator
    # # ---------------------
    #
    # Select a random half batch of images
    idx = np.random.randint(0, X_noise.shape[0], half_batch)
    imgs = X_noise[idx]
    labels = y_pose[idx]
    refined_imgs = X_refined[idx]
    # Generate a half batch of new images
    gen_imgs = generator.predict(imgs)

    # Add noise to the labels
    valid = np.ones((half_batch, discriminator_output_shape[1], discriminator_output_shape[2]))
    # valid += 0.05 * np.random.random(valid.shape)   ~~~~~~~~~~~~~~~~~~~~
    fake = np.zeros((half_batch, discriminator_output_shape[1], discriminator_output_shape[2]))
    # fake += 0.05 * np.random.random(fake.shape)    # add noise to the label  ~~~~~~~~~~~~~~~

    ################# use a history of refined images ####################3
    half_batch_from_image_history = image_history_buffer.get_from_image_history_buffer()
    image_history_buffer.add_to_image_history_buffer(gen_imgs)

    if len(half_batch_from_image_history):
        refined_imgs[:batch_size // 2] = half_batch_from_image_history

    # 生成数据的fake_label的标签为001, 真实的label的标签为100和010
    # Train the discriminator
    d_loss_real = discriminator.train_on_batch(refined_imgs, valid)
    d_loss_fake = discriminator.train_on_batch(gen_imgs, fake)
    d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

    # ---------------------
    #  Train Generator
    # ---------------------
    # Select a random half batch of images
    idx = np.random.randint(0, X_noise.shape[0], batch_size)
    imgs = X_noise[idx]
    refined_imgs = X_refined[idx]

    # Generator wants the discriminator to label the generated images as valid  !!!!!!!!! pay attention！！！！
    valid = np.ones((batch_size,  discriminator_output_shape[1], discriminator_output_shape[2]))
    # valid += 0.05 * np.random.random(valid.shape)   ~~~~~~~~~~~~~~~~

    # Train the generator
    g_loss = d_on_g.train_on_batch(imgs, [refined_imgs, valid])


    # g_loss = generator.train_on_batch(imgs, refined_imgs)  # 对于函数 generator.test_on_batch()，返回验证集上的test loss
    # write_log(callback, train_names, g_loss, epoch)
    #
    # Plot the progress
    # print("%d [D loss: %f] [G loss: %f, mse: %f]" % (
    #     epoch, d_loss, g_loss[0], g_loss[1]))
    # model.train_on_batch 除了返回total loss和子loss之外，如果还指定了metrics，还会返回metrics
    # If at save interval => save generated image samples

    if epoch % 4000 == 0 and epoch != 0:   # Reduce the learning rate for about every 10 epoch
        lr1 = K.get_value(g_optim.lr)
        K.set_value(g_optim.lr, 0.2 * lr1)  # lr变成原来的0.2倍
        lr2 = K.get_value(g_optim.lr)
        print('Reducing the learning rate from {} to {}'.format(lr1, lr2))

    if epoch % save_interval == 0:
        # # Select a random half batch of images
        indx = np.random.randint(0, X_noise.shape[0], half_batch)
        indxval = np.random.randint(0, X_val.shape[0], half_batch)

        noise_imgs = X_noise[indx]

        refined_imgs = X_refined[indx]
        gen_image = generator.predict(noise_imgs)

        # val_loss = generator.test_on_batch(X_val[indxval], Y_val[indxval])

        # write_log(callback, val_names, val_loss, epoch)

        # save_imgs(epoch, noise_imgs, gen_imgs, show_frames=9, save_path='training_process_images')
        save_imgs(epoch, noise_imgs, gen_image, show_frames=9, save_path='training_process_images')

        print("%d [D loss: %f] [G loss: %f, mse: %f, adv_loss: %f]" % (
            epoch, d_loss, g_loss[0], g_loss[1], g_loss[2]))
        # loss出现负数的原因是label加入了噪声，使tf中的loss: z * -log(sigmoid(x)) + (1 - z) * -log(1 - sigmoid(x))出现了负数
        # print("%d [D loss: %f] " % (epoch, d_loss))
        generator.save('weights/my_generator_%d.hdf5' % epoch)
        discriminator.save('weights/my_discriminator_%d.hdf5' % epoch)

