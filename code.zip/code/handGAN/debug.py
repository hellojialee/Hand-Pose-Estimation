import numpy as np
from keras.models import load_model
import h5py
import matplotlib.pyplot as plt
from utils.plot_images import *
import scipy.io as sio
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

generator = load_model('my_skip_mode.hdf5')

# load data
with h5py.File('data/train_0.h5') as f:
    X_noise = f['depth'][:]
    X_noise = np.transpose(X_noise, (0, 2, 3, 1))
    y_pose = f['joint'][:]

# load data
with h5py.File('data/synth_train_0.h5') as f:
    X_refined = f['depth'][:]
    X_refined = np.transpose(X_refined, (0, 2, 3, 1))

indx = np.random.randint(0, X_noise.shape[0], 16)
noise_imgs = X_noise[indx]

refined_imgs = X_refined[indx]
gen_image = generator.predict(noise_imgs)

difference = refined_imgs - gen_image

show_image = visualize_grid(difference)
plt.figure(figsize=(10, 10))
plt.imshow(show_image, cmap='gray')
plt.show()

sio.savemat('saveddata.mat', {'gen_image': np.squeeze(gen_image), 'refined_image': np.squeeze(refined_imgs)})
save_imgs(3, noise_imgs, gen_image, show_frames=9, save_path='.')
save_imgs(4, refined_imgs, gen_image, show_frames=9, save_path='.')
